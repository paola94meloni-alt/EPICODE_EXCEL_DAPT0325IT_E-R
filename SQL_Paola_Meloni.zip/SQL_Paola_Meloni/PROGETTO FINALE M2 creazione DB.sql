#creo il DB
CREATE DATABASE negozio_giocattoli;
USE negozio_giocattoli;
#creo le tabelle e la loro struttura e le metto in relazione con PK e FK
CREATE TABLE categoria (
categoria_ID INT AUTO_INCREMENT PRIMARY KEY,
nome_categoria VARCHAR (100)
);
CREATE TABLE regione (
regione_ID INT AUTO_INCREMENT PRIMARY KEY,
nome_regione VARCHAR (100)
);
CREATE TABLE prodotto (
prodotto_ID INT AUTO_INCREMENT PRIMARY KEY,
nome_prodotto VARCHAR (100),
prezzo_prodotto DECIMAL (8,2),
categoria_ID INT,
FOREIGN KEY (categoria_ID) REFERENCES categoria (categoria_ID)
);
CREATE TABLE stato (
stato_ID INT AUTO_INCREMENT PRIMARY KEY,
nome_stato VARCHAR (100),
regione_ID INT,
FOREIGN KEY (regione_ID) REFERENCES regione (regione_ID)
);
CREATE TABLE vendita (
vendita_ID INT AUTO_INCREMENT PRIMARY KEY,
data_vendita DATE,
prodotto_ID INT,
stato_ID INT,
quantita INT,
importo_totale DECIMAL (8,2),
FOREIGN KEY (prodotto_ID) REFERENCES prodotto (prodotto_ID),
FOREIGN KEY (stato_ID) REFERENCES stato (stato_ID)
);
#popolo le tabelle e con select*from verifico che i dati siano stati inseriti come voglio
INSERT INTO categoria 
(nome_categoria) 
VALUES
('Bici'),
('Abbigliamento'),
('Giochi da tavolo'),
('Peluche');
SELECT * FROM categoria;
INSERT INTO regione 
(nome_regione) 
VALUES
('Europa Occidentale'),
('Europa Meridionale'),
('Nord America'),
('Asia Pacifico');
SELECT * FROM regione;
INSERT INTO prodotto 
(nome_prodotto, prezzo_prodotto, categoria_ID) 
VALUES
('Bici-100', 199.99, 1),
('Bici-200', 299.99, 1),
('Guanti Bici M', 24.99, 2),
('Guanti Bici L', 24.99, 2),
('Monopoly Italiano', 39.90, 3),
('Cluedo Italiano', 34.90, 3),
('Peluche Orso Grande', 49.90, 4),
('Peluche Gatto Piccolo', 29.90, 4);
SELECT * FROM prodotto;
INSERT INTO stato 
(nome_stato, regione_ID) 
VALUES
('Francia', 1),
('Germania', 1),
('Italia', 2),
('Grecia', 2),
('USA', 3),
('Giappone', 4);
SELECT * FROM stato;
INSERT INTO vendita 
(prodotto_ID, stato_ID, data_vendita, quantita, importo_totale) VALUES
(1, 3, '2025-01-15', 5, 999.95),
(3, 3, '2025-02-10', 10, 249.90),
(5, 2, '2024-11-20', 3, 119.70),
(7, 3, '2024-12-05', 2, 99.80),
(2, 2, '2025-03-22', 4, 1199.96),
(6, 4, '2025-04-01', 6, 209.40),
(8, 5, '2025-05-10', 1, 29.90),
(3, 3, '2024-10-30', 8, 199.92),
(7, 3, '2024-03-15', 1, 49.90),
(5, 3, '2023-11-25', 4, 159.60);
SELECT * FROM vendita;




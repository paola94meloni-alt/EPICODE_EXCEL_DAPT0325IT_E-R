#Scrivo le query per interrogare il mio DB
# 1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità 
#dei valori di ciascuna PK (una query per tabella implementata).
SELECT categoria_ID
FROM categoria
WHERE categoria_ID IS NULL;
SELECT 
categoria_ID,
COUNT(*)
FROM categoria
GROUP BY categoria_ID
HAVING COUNT(*) > 1; 
#se tutte e due queste SELECT non restituiscono records, significa che le PK sono univoche e mai null
SELECT prodotto_ID
FROM prodotto
WHERE prodotto_ID IS NULL;
SELECT 
prodotto_ID,
COUNT(*)
FROM prodotto
GROUP BY prodotto_ID
HAVING COUNT(*) > 1;
SELECT regione_ID
FROM regione
WHERE regione_ID IS NULL;
SELECT 
regione_ID,
COUNT(*)
FROM regione
GROUP BY regione_ID
HAVING COUNT(*) > 1;
SELECT stato_ID
FROM stato
WHERE stato_ID IS NULL;
SELECT 
stato_ID,
COUNT(*)
FROM stato
GROUP BY stato_ID
HAVING COUNT(*) > 1;
SELECT vendita_ID
FROM vendita
WHERE vendita_ID IS NULL;
SELECT 
vendita_ID,
COUNT(*)
FROM vendita
GROUP BY vendita_ID
HAVING COUNT(*) > 1;
# 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
#il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati 
#più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT
v.vendita_ID AS codice_documento,
v.data_vendita,
p.nome_prodotto,
c.nome_categoria,
s.nome_stato,
r.nome_regione,
IF(DATEDIFF(CURDATE(), v.data_vendita) > 180, 'TRUE', 'FALSE') AS superati_180_giorni
FROM vendita AS v
INNER JOIN
prodotto AS p
ON 
v.prodotto_ID = p.prodotto_ID
INNER JOIN
categoria AS c
ON 
p.categoria_ID = c.categoria_ID
INNER JOIN 
stato AS s
ON 
s.stato_ID = v.stato_ID
INNER JOIN 
regione AS r
ON 
r.regione_ID = s.regione_ID;
# 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito.
#(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto 
# e il totale venduto.
SELECT
prodotto_ID AS codice_prodotto,
SUM(importo_totale) AS totale_fatturato
FROM vendita
WHERE YEAR(data_vendita) = (SELECT MAX(YEAR (data_vendita)) FROM vendita)
GROUP BY prodotto_ID
HAVING SUM(quantita) >
(SELECT AVG(quantita) FROM vendita);
/*SELECT 
prodotto_ID,
SUM(quantita)
#(SELECT SUM(a.quantita) FROM vendita as a) AS totale 
FROM vendita 
GROUP BY prodotto_ID
HAVING SUM(quantita) >
(select AVG(quantita) FROM vendita);
SELECT AVG(quantita) FROM vendita;*/
#4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT
p.nome_prodotto,
SUM(v.importo_totale) AS fatturato_totale,
YEAR(data_vendita) AS anno
FROM prodotto AS p
INNER JOIN 
vendita AS v
ON 
p.prodotto_ID = v.prodotto_ID
GROUP BY p.nome_prodotto, YEAR(v.data_vendita)
ORDER BY p.nome_prodotto, anno;
#5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT
s.nome_stato AS stato,
SUM(v.importo_totale) AS fatturato_totale,
YEAR(data_vendita) AS anno
FROM stato AS s
INNER JOIN 
vendita AS v
ON 
s.stato_ID = v.stato_ID
GROUP BY s.nome_stato, YEAR(v.data_vendita)
ORDER BY fatturato_totale DESC, anno DESC;
#6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
c.nome_categoria,
SUM(v.quantita) AS totale_venduto
FROM categoria AS c
INNER JOIN prodotto AS p
ON c.categoria_ID = p.categoria_ID
INNER JOIN vendita AS v
ON 
p.prodotto_ID = v.prodotto_ID
GROUP BY c.nome_categoria
ORDER BY totale_venduto DESC;
#7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
#PRIMO CASO RISOLUTIVO: uso una LEFT JOIN così son sicura di prendere tutti i prodotti, se ci sono dei prodotti invenduti l'ID vendita sarà NULL,
#quindi con la where vado a filtrare proprio questi prodotti.
SELECT
p.nome_prodotto
FROM prodotto AS p
LEFT JOIN 
vendita AS v
ON 
p.prodotto_ID = v.prodotto_ID
WHERE v.vendita_ID IS NULL;
#SECONDO CASO RISOLUTIVO: uso una SUBQUERY cercando i nomi dei prodotti per cui l'ID prodotto non è contenuto nella tabella delle vendite
SELECT
    nome_prodotto
FROM prodotto
WHERE prodotto_ID NOT IN (SELECT prodotto_ID FROM vendita);
#8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW PRODOTTI_VIEW AS 
(
SELECT 
p.prodotto_ID,
p.nome_prodotto,
c.nome_categoria
FROM
prodotto AS p
INNER JOIN
categoria AS c
ON 
p.categoria_ID = c.categoria_ID
);
#9)	Creare una vista per le informazioni geografiche
CREATE VIEW INFO_GEOGRAFICHE AS 
(
SELECT 
r.nome_regione,
s.nome_stato
FROM
regione AS r
INNER JOIN
stato AS s
ON 
r.regione_ID = s.regione_ID
);